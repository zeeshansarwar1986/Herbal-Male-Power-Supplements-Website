import { motion, AnimatePresence } from 'framer-motion';
import { useState, useRef, useEffect, type ChangeEvent } from 'react';
import { X, Upload, Phone, CreditCard, MapPin, User, Package, ChevronDown } from 'lucide-react';
import { orderConfig, exploreConfig } from '../../config';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  productName?: string;
  productPrice?: string;
}

interface FormData {
  name: string;
  phone: string;
  address: string;
  product: string;
}

const products = exploreConfig.hotspots.map(h => ({
  name: h.title,
  price: h.description.match(/قیمت:\s*([\d,]+)\s*روپے/)?.[1] + ' روپے' || ''
}));

export function OrderModal({ isOpen, onClose, productName = '', productPrice = '' }: OrderModalProps) {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    phone: '',
    address: '',
    product: productName,
  });
  const [selectedPrice, setSelectedPrice] = useState(productPrice);
  const [screenshotPreview, setScreenshotPreview] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showProductDropdown, setShowProductDropdown] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setFormData({
        name: '',
        phone: '',
        address: '',
        product: productName,
      });
      setSelectedPrice(productPrice);
      setShowProductDropdown(!productName);
    }
  }, [isOpen, productName, productPrice]);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProductSelect = (productName: string, productPrice: string) => {
    setFormData(prev => ({ ...prev, product: productName }));
    setSelectedPrice(productPrice);
    setShowProductDropdown(false);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const submitToGoogleSheet = async (data: FormData & { screenshot: string; timestamp: string }) => {
    try {
      const response = await fetch(orderConfig.googleSheetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      return response.ok;
    } catch (error) {
      console.error('Error submitting to Google Sheet:', error);
      return false;
    }
  };

  const sendToWhatsApp = (data: FormData) => {
    const message = `
*نیا آرڈر - مردانہ طاقت*

*مصنوع:* ${data.product}
*قیمت:* ${selectedPrice}

*نام:* ${data.name}
*فون:* ${data.phone}
*پتہ:* ${data.address}

*ادائیگی:* ایزی پیسہ - ${orderConfig.easyPaisaNumber}
*ایڈوانس:* ${orderConfig.advanceAmount} روپے
    `.trim();

    const whatsappUrl = `https://wa.me/${orderConfig.whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const timestamp = new Date().toISOString();
    const submissionData = {
      ...formData,
      screenshot: screenshotPreview || '',
      timestamp,
    };

    // Submit to Google Sheet
    await submitToGoogleSheet(submissionData);

    // Send to WhatsApp
    sendToWhatsApp(formData);

    setIsSubmitting(false);
    setShowSuccess(true);

    setTimeout(() => {
      setShowSuccess(false);
      onClose();
      setFormData({ name: '', phone: '', address: '', product: '' });
      setScreenshotPreview('');
    }, 3000);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleBackdropClick}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-[#05140A]/95 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal Content */}
          <motion.div
            className="relative bg-gradient-to-br from-[#0D2818] to-[#05140A] border border-[#C9A227]/40 rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-[#C9A227]/10 flex items-center justify-center text-[#C9A227] hover:bg-[#C9A227]/20 transition-colors"
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Success Message */}
            <AnimatePresence>
              {showSuccess && (
                <motion.div
                  className="absolute inset-0 z-20 flex items-center justify-center bg-gradient-to-br from-[#0D2818] to-[#05140A] rounded-xl"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <div className="text-center p-8">
                    <motion.div
                      className="w-20 h-20 mx-auto mb-6 rounded-full bg-[#C9A227]/20 flex items-center justify-center"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', damping: 15 }}
                    >
                      <svg className="w-10 h-10 text-[#C9A227]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </motion.div>
                    <h3 className="text-2xl font-bold text-[#F5F5DC] mb-2">{orderConfig.successMessage}</h3>
                    <p className="text-[#8FBC8F]">وٹس ایپ پر رابطہ کر دیا گیا ہے</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Header */}
            <div className="p-6 border-b border-[#C9A227]/20">
              <h2 className="text-2xl font-bold text-[#F5F5DC] text-center">{orderConfig.formTitle}</h2>
              <p className="text-[#8FBC8F] text-center text-sm mt-1">{orderConfig.formSubtitle}</p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              {/* Product Display / Selector */}
              <div className="bg-[#C9A227]/10 border border-[#C9A227]/30 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Package className="w-5 h-5 text-[#C9A227]" />
                  <span className="text-[#8FBC8F] text-sm">{orderConfig.productLabel}</span>
                </div>
                
                {showProductDropdown ? (
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setShowProductDropdown(!showProductDropdown)}
                      className="w-full bg-[#05140A] border border-[#C9A227]/30 rounded-lg px-4 py-3 text-[#F5F5DC] flex items-center justify-between"
                    >
                      <span>{formData.product || 'مصنوع منتخب کریں'}</span>
                      <ChevronDown className="w-5 h-5 text-[#C9A227]" />
                    </button>
                    <div className="absolute z-10 w-full mt-1 bg-[#0D2818] border border-[#C9A227]/30 rounded-lg max-h-48 overflow-y-auto">
                      {products.map((product) => (
                        <button
                          key={product.name}
                          type="button"
                          onClick={() => handleProductSelect(product.name, product.price)}
                          className="w-full px-4 py-3 text-right text-[#F5F5DC] hover:bg-[#C9A227]/20 transition-colors border-b border-[#C9A227]/10 last:border-0"
                        >
                          <p className="font-semibold">{product.name}</p>
                          <p className="text-[#C9A227] text-sm">{product.price}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div 
                    className="cursor-pointer"
                    onClick={() => !productName && setShowProductDropdown(true)}
                  >
                    <p className="text-[#F5F5DC] font-semibold">{formData.product}</p>
                    {selectedPrice && (
                      <p className="text-[#C9A227] text-sm mt-1">{selectedPrice}</p>
                    )}
                    {!productName && (
                      <p className="text-[#8FBC8F] text-xs mt-1">تبدیل کرنے کے لیے کلک کریں</p>
                    )}
                  </div>
                )}
              </div>

              {/* Name Input */}
              <div>
                <label className="flex items-center gap-2 text-[#8FBC8F] text-sm mb-2">
                  <User className="w-4 h-4" />
                  {orderConfig.nameLabel} *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#05140A] border border-[#C9A227]/30 rounded-lg px-4 py-3 text-[#F5F5DC] placeholder-[#8FBC8F]/50 focus:outline-none focus:border-[#C9A227] transition-colors"
                  placeholder="اپنا پورا نام لکھیں"
                />
              </div>

              {/* Phone Input */}
              <div>
                <label className="flex items-center gap-2 text-[#8FBC8F] text-sm mb-2">
                  <Phone className="w-4 h-4" />
                  {orderConfig.phoneLabel} *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#05140A] border border-[#C9A227]/30 rounded-lg px-4 py-3 text-[#F5F5DC] placeholder-[#8FBC8F]/50 focus:outline-none focus:border-[#C9A227] transition-colors"
                  placeholder="03XX-XXXXXXX"
                />
              </div>

              {/* Address Input */}
              <div>
                <label className="flex items-center gap-2 text-[#8FBC8F] text-sm mb-2">
                  <MapPin className="w-4 h-4" />
                  {orderConfig.addressLabel} *
                </label>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  required
                  rows={3}
                  className="w-full bg-[#05140A] border border-[#C9A227]/30 rounded-lg px-4 py-3 text-[#F5F5DC] placeholder-[#8FBC8F]/50 focus:outline-none focus:border-[#C9A227] transition-colors resize-none"
                  placeholder="اپنا مکمل پتہ لکھیں"
                />
              </div>

              {/* Payment Info */}
              <div className="bg-gradient-to-r from-[#C9A227]/20 to-[#8FBC8F]/10 border border-[#C9A227]/40 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <CreditCard className="w-5 h-5 text-[#C9A227]" />
                  <span className="text-[#F5F5DC] font-semibold">{orderConfig.paymentLabel}</span>
                </div>
                <p className="text-[#8FBC8F] text-sm mb-3">
                  {orderConfig.paymentInstructions
                    .replace('{amount}', orderConfig.advanceAmount)
                    .replace('{number}', orderConfig.easyPaisaNumber)}
                </p>
                <div className="bg-[#05140A] rounded-lg p-3 text-center">
                  <p className="text-[#C9A227] font-mono text-lg font-bold">{orderConfig.easyPaisaNumber}</p>
                  <p className="text-[#8FBC8F] text-xs mt-1">{orderConfig.easyPaisaName}</p>
                </div>
              </div>

              {/* Screenshot Upload */}
              <div>
                <label className="flex items-center gap-2 text-[#8FBC8F] text-sm mb-2">
                  <Upload className="w-4 h-4" />
                  {orderConfig.screenshotLabel} *
                </label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-[#05140A] border-2 border-dashed border-[#C9A227]/40 rounded-lg px-4 py-6 text-center cursor-pointer hover:border-[#C9A227] transition-colors"
                >
                  {screenshotPreview ? (
                    <img
                      src={screenshotPreview}
                      alt="Payment Screenshot"
                      className="max-h-32 mx-auto rounded-lg"
                    />
                  ) : (
                    <div className="text-[#8FBC8F]">
                      <Upload className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">ادائیگی کا اسکرین شاٹ اپلوڈ کریں</p>
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    required
                    className="hidden"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-3 border border-[#C9A227]/40 text-[#8FBC8F] rounded-lg hover:bg-[#C9A227]/10 transition-colors"
                >
                  {orderConfig.cancelButton}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-[#C9A227] to-[#8FBC8F] text-[#05140A] font-semibold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {isSubmitting ? ' alsoجھے رہا ہے...' : orderConfig.submitButton}
                </button>
              </div>
            </form>

            {/* Decorative Border */}
            <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-[#C9A227] to-transparent" />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
