// ============================================================================
// Configuration File for Mardana Taqat Capsules Website
// ============================================================================
// Edit this file to customize all content on your site.
// Do NOT modify component files - they read from this config.

// Hero Section Configuration
export interface HeroConfig {
  subtitle: string;
  titleLine1: string;
  titleLine2: string;
  tagline: string;
  chocolateText: string;
  ctaText: string;
  heroImage: string;
  leafImages: [string, string];
}

export const heroConfig: HeroConfig = {
  subtitle: "قدرتی جڑی بوٹیوں کا خزانہ",
  titleLine1: "مردانہ",
  titleLine2: "طاقت",
  tagline: "100% قدرتی · بغیر کسی ضمنی اثر کے",
  chocolateText: "پاکستان کا نمبر ون ہربل کیپسول",
  ctaText: "مصنوعات دیکھیں",
  heroImage: "images/hero_capsules.jpg",
  leafImages: ["images/leaf_1.png", "images/leaf_2.png"],
};

// Story Section Configuration
export interface StoryStatConfig {
  value: string;
  label: string;
}

export interface StoryConfig {
  label: string;
  heading: string[];
  headingAccent: string;
  paragraphs: string[];
  stats: StoryStatConfig[];
  storyImage: string;
}

export const storyConfig: StoryConfig = {
  label: "ہمارا قصہ",
  heading: ["صدیوں پرانا"],
  headingAccent: "حکمت کا سر",
  paragraphs: [
    "ہمارے آباؤ اجداد نے ہزاروں سالوں سے جڑی بوٹیوں میں شفا یابی کی طاقت دریافت کی ہے۔ ہم نے ان قیمتی رازوں کو جدید سائنس کے ساتھ ملا کر ایسے کیپسول تیار کیے ہیں جو مردانہ صحت اور طاقت کو فطری طور پر بحال کرتے ہیں۔",
    "ہر کیپسول میں صرف انتہائی معیاری جڑی بوٹیاں استعمال کی جاتی ہیں جو پاکستان کے پہاڑی علاقوں سے دستیاب کی جاتی ہیں۔ کوئی کیمیکل، کوئی نقصان دہ مادہ نہیں۔",
    "ہمارا مقصد صرف فروخت نہیں، بلکہ ہر مرد کو صحت مند، طاقتور اور خود مختار بنانا ہے۔"
  ],
  stats: [
    { value: "50K+", label: "مطمئن گاہک" },
    { value: "100%", label: "قدرتی" },
    { value: "5", label: "منفرد مصنوعات" },
    { value: "24/7", label: "کسٹمر سپورٹ" }
  ],
  storyImage: "images/hakim.jpg",
};

// Product Section Configuration
export interface ProductConfig {
  label: string;
  heading: string[];
  headingAccent: string;
  productTitle: string;
  description: string;
  features: string[];
  price: string;
  priceLabel: string;
  specs: string;
  specsLabel: string;
  ctaPrimary: string;
  ctaSecondary: string;
  productImage: string;
}

export const productConfig: ProductConfig = {
  label: "بہترین مصنوع",
  heading: ["شاہی"],
  headingAccent: "پاور",
  productTitle: "شاہی پاور کیپسول",
  description: "ہماری سب سے مقبول مصنوع جو 15 قیمتی جڑی بوٹیوں کا مجموعہ ہے۔ یہ کیپسول مردانہ طاقت، برداشت، اور توانائی میں نمایاں بہتری لاتا ہے۔",
  features: [
    "15 قدرتی جڑی بوٹیاں",
    "توانائی میں فوری اضافہ",
    "برداشت میں بہتری",
    "قوت مدافعت مضبوط",
    "ذہنی سکون",
    "کوئی ضمنی اثر نہیں"
  ],
  price: "2,999 روپے",
  priceLabel: "قیمت",
  specs: "30 کیپسول / ڈبہ",
  specsLabel: "مقدار",
  ctaPrimary: "ابھی خریدیں",
  ctaSecondary: "مزید جانیں",
  productImage: "images/product_main.jpg",
};

// Explore Section Configuration - Now showing 5 products as hotspots
export interface HotspotConfig {
  id: string;
  x: number;
  y: number;
  title: string;
  description: string;
  iconType: "bird" | "pawprint" | "treepine" | "flower";
  image: string;
}

export interface ExploreConfig {
  label: string;
  heading: string[];
  headingAccent: string;
  description: string;
  hint: string;
  exploreImage: string;
  hotspots: HotspotConfig[];
}

export const exploreConfig: ExploreConfig = {
  label: "ہماری مصنوعات",
  heading: ["5 منفرد"],
  headingAccent: "کیپسول",
  description: "ہر ضرورت کے لیے ایک خاص کیپسول۔ ہمارے 5 منفرد فارمولے جو مختلف صحت کے مسائل کا حل پیش کرتے ہیں۔",
  hint: "ہر مصنوع پر کلک کریں تفصیلات کے لیے",
  exploreImage: "images/explore_herbs.jpg",
  hotspots: [
    {
      id: "product1",
      x: 20,
      y: 30,
      title: "شاہی پاور",
      description: "مکمل طاقت کا حل - 15 جڑی بوٹیوں کا شاہکار مجموعہ۔ قیمت: 2,999 روپے",
      iconType: "treepine",
      image: "images/product1.png"
    },
    {
      id: "product2",
      x: 50,
      y: 25,
      title: "سلسلہ سٹامینا",
      description: "برداشت اور توانائی کے لیے خاص۔ جم کے لیے بہترین۔ قیمت: 2,499 روپے",
      iconType: "pawprint",
      image: "images/product2.png"
    },
    {
      id: "product3",
      x: 80,
      y: 35,
      title: "وائٹالٹی بوسٹ",
      description: "روزمرہ توانائی اور فعالیت کے لیے۔ قیمت: 1,999 روپے",
      iconType: "flower",
      image: "images/product3.png"
    },
    {
      id: "product4",
      x: 35,
      y: 65,
      title: "مچورٹی پلس",
      description: "40+ عمر کے مردوں کے لیے خاص فارمولا۔ قیمت: 2,799 روپے",
      iconType: "bird",
      image: "images/product4.png"
    },
    {
      id: "product5",
      x: 65,
      y: 70,
      title: "نیچرل وائگور",
      description: "نوجوانوں کے لیے قدرتی توانائی کا ذریعہ۔ قیمت: 1,799 روپے",
      iconType: "treepine",
      image: "images/product5.png"
    }
  ],
};

// Tasting Section Configuration - Changed to Benefits Section
export interface TastingCardConfig {
  iconType: "eye" | "wind" | "sparkles";
  title: string;
  description: string;
  notes: string[];
}

export interface FlavorBarConfig {
  label: string;
  value: number;
  color: string;
}

export interface TastingConfig {
  label: string;
  heading: string[];
  headingAccent: string;
  description: string;
  tastingCards: TastingCardConfig[];
  flavorWheel: {
    title: string;
    description: string;
    tags: string[];
    bars: FlavorBarConfig[];
  };
}

export const tastingConfig: TastingConfig = {
  label: "فوائد کی دنیا",
  heading: ["صحت کے"],
  headingAccent: "راز",
  description: "ہمارے کیپسولز کے استعمال سے حاصل ہونے والے بنیادی فوائد",
  tastingCards: [
    {
      iconType: "eye",
      title: "طاقت و توانائی",
      description: "روزمرہ کاموں میں توانائی اور فعالیت میں نمایاں بہتری",
      notes: ["فوری توانائی", "طویل مدتی اثر", "کوئی تھکاوٹ"]
    },
    {
      iconType: "wind",
      title: "ذہنی سکون",
      description: "تناؤ سے نجات اور ذہنی طور پر پرسکون رہنے کی صلاحیت",
      notes: ["تناؤ کم", "بہتر نیند", "ذہنی توجہ"]
    },
    {
      iconType: "sparkles",
      title: "قوت مدافعت",
      description: "جسم کی بیماریوں سے لڑنے کی قدرتی صلاحیت میں اضافہ",
      notes: ["کم بیماریاں", "تیز صحت یابی", "مضبوط جسم"]
    }
  ],
  flavorWheel: {
    title: "جڑی بوٹیوں کی طاقت",
    description: "ہر کیپسول میں موجود قدرتی اجزاء کا تناسب",
    tags: ["اشوگندھا", "سفید مصری", "سلاجیت", "گوکشورا", "کونچ", "شلاجیت"],
    bars: [
      { label: "توانائی", value: 95, color: "#C9A227" },
      { label: "برداشت", value: 90, color: "#8FBC8F" },
      { label: "طاقت", value: 88, color: "#C9A227" },
      { label: "سکون", value: 85, color: "#8FBC8F" }
    ]
  },
};

// Footer Section Configuration
export interface SocialLinkConfig {
  platform: "instagram" | "facebook" | "twitter";
  href: string;
}

export interface NavLinkConfig {
  label: string;
  href: string;
}

export interface PolicyLinkConfig {
  label: string;
  href: string;
}

export interface FooterConfig {
  brandName: string;
  brandTagline: string;
  brandDescription: string;
  socialLinks: SocialLinkConfig[];
  navSectionTitle: string;
  navLinks: NavLinkConfig[];
  contactSectionTitle: string;
  contactAddress: string;
  contactPhone: string;
  contactEmail: string;
  newsletterTitle: string;
  newsletterDescription: string;
  newsletterPlaceholder: string;
  newsletterButton: string;
  copyright: string;
  policyLinks: PolicyLinkConfig[];
}

export const footerConfig: FooterConfig = {
  brandName: "مردانہ طاقت",
  brandTagline: "قدرت کا تحفہ",
  brandDescription: "پاکستان کی سب سے قابل اعتماد ہربل کیپسول برانڈ۔ 50,000+ مطمئن گاہکوں کا اعتماد۔",
  socialLinks: [
    { platform: "instagram", href: "#" },
    { platform: "facebook", href: "#" },
    { platform: "twitter", href: "#" }
  ],
  navSectionTitle: "فوری لنکس",
  navLinks: [
    { label: "ہوم", href: "#" },
    { label: "مصنوعات", href: "#" },
    { label: "ہمارا قصہ", href: "#" },
    { label: "رابطہ", href: "#" }
  ],
  contactSectionTitle: "رابطہ کریں",
  contactAddress: "لاہور، پنجاب، پاکستان",
  contactPhone: "+92 300 1234567",
  contactEmail: "info@mardanataqat.pk",
  newsletterTitle: "خبرنامہ",
  newsletterDescription: "تازہ ترین آفرز اور مصنوعات کی معلومات حاصل کریں",
  newsletterPlaceholder: "اپنا ای میل درج کریں",
  newsletterButton: "سبسکرائب",
  copyright: "© 2025 مردانہ طاقت۔ جملہ حقوق محفوظ ہیں۔",
  policyLinks: [
    { label: "پرائیویسی پالیسی", href: "#" },
    { label: "Terms of Service", href: "#" }
  ],
};

// Site Metadata
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "مردانہ طاقت کیپسولز - قدرتی جڑی بوٹیوں کا خزانہ",
  description: "پاکستان کا نمبر ون ہربل کیپسول برانڈ۔ 100% قدرتی جڑی بوٹیوں سے تیار شدہ مردانہ طاقت کے کیپسولز۔",
  language: "ur",
};

// Order Configuration
export interface OrderConfig {
  easyPaisaNumber: string;
  easyPaisaName: string;
  whatsappNumber: string;
  advanceAmount: string;
  googleSheetUrl: string;
  formTitle: string;
  formSubtitle: string;
  nameLabel: string;
  phoneLabel: string;
  addressLabel: string;
  productLabel: string;
  paymentLabel: string;
  screenshotLabel: string;
  submitButton: string;
  cancelButton: string;
  paymentInstructions: string;
  successMessage: string;
}

export const orderConfig: OrderConfig = {
  easyPaisaNumber: "0345-1234567",
  easyPaisaName: "مردانہ طاقت",
  whatsappNumber: "923001234567",
  advanceAmount: "500",
  googleSheetUrl: "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec",
  formTitle: "آرڈر فارم",
  formSubtitle: "براہ کرم اپنی تفصیلات درج کریں",
  nameLabel: "پورا نام",
  phoneLabel: "موبائل نمبر",
  addressLabel: "مکمل پتہ",
  productLabel: "مصنوع",
  paymentLabel: "ادائیگی کی تفصیل",
  screenshotLabel: "اسکرین شاٹ اپلوڈ کریں",
  submitButton: "آرڈر بھیجیں",
  cancelButton: "منسوخ کریں",
  paymentInstructions: "ایزی پیسہ سے {amount} روپے {number} پر بھیجیں اور اسکرین شاٹ لگائیں",
  successMessage: "آپ کا آرڈر کامیابی سے بھیج دیا گیا!",
};
